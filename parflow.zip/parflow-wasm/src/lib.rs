use wasm_bindgen::prelude::*;
use wasm_bindgen_futures::future_to_promise;
use js_sys::Promise;

/// run_js_par returns a JS Promise that resolves to the sum of results.
#[wasm_bindgen]
pub fn run_js_par() -> Promise {
    future_to_promise(async {
        let v = parflow_core::run_example_par().await;
        let sum: i32 = v.into_iter().sum();
        Ok(JsValue::from_f64(sum as f64))
    })
}

#[cfg(test)]
mod tests {
    use wasm_bindgen_test::*;
    wasm_bindgen_test::wasm_bindgen_test_configure!(run_in_browser);

    #[wasm_bindgen_test(async)]
    async fn test_run_js_par() {
        let val = wasm_bindgen_futures::JsFuture::from(run_js_par()).await.unwrap();
        let num = val.as_f64().unwrap() as i32;
        assert_eq!(num, 3);
    }
}
