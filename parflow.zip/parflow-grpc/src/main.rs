use tonic::{transport::Server, Request, Response, Status};
use parflow::orchestrator_server::{Orchestrator, OrchestratorServer};
use parflow::{OrchestratorRequest, OrchestratorResponse};

pub mod parflow {
    tonic::include_proto!("parflow");
}

#[derive(Default)]
pub struct MyOrchestrator {}

#[tonic::async_trait]
impl Orchestrator for MyOrchestrator {
    async fn run(
        &self,
        _request: Request<OrchestratorRequest>,
    ) -> Result<Response<OrchestratorResponse>, Status> {
        // call core example (parallel)
        let results = parflow_core::run_example_par().await;
        let reply = OrchestratorResponse { results };
        Ok(Response::new(reply))
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let addr = "[::1]:50051".parse()?;
    println!("gRPC listening on {}", addr);
    Server::builder()
        .add_service(OrchestratorServer::new(MyOrchestrator::default()))
        .serve(addr)
        .await?;
    Ok(())
}
