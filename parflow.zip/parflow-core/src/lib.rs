use futures::future::join_all;
use futures::future::BoxFuture;
use futures::FutureExt;
use std::time::Duration;
use tokio::time::sleep;

/// Helper to box an async i32-producing future.
pub fn boxed_task<F>(f: F) -> BoxFuture<'static, i32>
where
    F: futures::Future<Output = i32> + Send + 'static,
{
    f.boxed()
}

/// Run tasks (that produce i32) in parallel and collect results.
pub async fn par(tasks: Vec<BoxFuture<'static, i32>>) -> Vec<i32> {
    join_all(tasks).await
}

/// Run tasks sequentially and collect results.
pub async fn seq(tasks: Vec<BoxFuture<'static, i32>>) -> Vec<i32> {
    let mut results = Vec::new();
    for t in tasks {
        results.push(t.await);
    }
    results
}

// Example tasks returning i32.
pub fn task1() -> BoxFuture<'static, i32> {
    boxed_task(async {
        sleep(Duration::from_millis(100)).await;
        1
    })
}

pub fn task2() -> BoxFuture<'static, i32> {
    boxed_task(async {
        sleep(Duration::from_millis(50)).await;
        2
    })
}

/// Run example tasks in parallel; returns Vec<i32>.
pub async fn run_example_par() -> Vec<i32> {
    par(vec![task1(), task2()]).await
}

/// Run example tasks sequentially; returns Vec<i32>.
pub async fn run_example_seq() -> Vec<i32> {
    seq(vec![task1(), task2()]).await
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_seq() {
        let res = run_example_seq().await;
        assert_eq!(res, vec![1, 2]);
    }

    #[tokio::test]
    async fn test_par() {
        let res = run_example_par().await;
        // Order preserved as tasks are same produced order
        assert_eq!(res, vec![1, 2]);
    }
}
