import ctypes
import os
import sys

# Adjust path as needed; this assumes you built parflow-c with `cargo build --release`
# and are running from repository root.
libname = "libparflow_c.so"
if sys.platform.startswith("darwin"):
    libname = "libparflow_c.dylib"
elif sys.platform.startswith("win"):
    libname = "parflow_c.dll"

libpath = os.path.join(os.getcwd(), "parflow-c", "target", "release", libname)
print("Trying to load", libpath)
lib = ctypes.CDLL(libpath)
res = lib.run_orchestrator_par()
print("Result from FFI (sum):", res)
