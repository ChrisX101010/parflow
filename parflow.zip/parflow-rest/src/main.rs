use axum::{routing::get, Router, Json};
use parflow_core::{run_example_par, run_example_seq};
use std::net::SocketAddr;

#[tokio::main]
async fn main() {
    let app = Router::new()
        .route("/par", get(handle_par))
        .route("/seq", get(handle_seq));

    let addr = SocketAddr::from(([0,0,0,0], 3000));
    println!("Listening on {}", addr);
    axum::Server::bind(&addr)
        .serve(app.into_make_service())
        .await
        .unwrap();
}

async fn handle_par() -> Json<Vec<i32>> {
    let vec = run_example_par().await;
    Json(vec)
}

async fn handle_seq() -> Json<Vec<i32>> {
    let vec = run_example_seq().await;
    Json(vec)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_handlers_direct() {
        let p = handle_par().await;
        assert_eq!(p.0, vec![1, 2]);
        let s = handle_seq().await;
        assert_eq!(s.0, vec![1, 2]);
    }
}
